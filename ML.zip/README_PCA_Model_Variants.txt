PCA comparison notebooks adapted from PCA_Comparison_Statistical_Testing.ipynb

FILES
- KNN_PCA_Comparison_Statistical_Testing.ipynb
- Linear_Regression_PCA_Comparison_Statistical_Testing.ipynb
- knn_sample_data.csv
- linear_regression_sample_data.csv

HOW TO RUN
1. Keep each notebook and its matching CSV in the same folder.
2. Open the notebook in Jupyter Notebook, JupyterLab, or VS Code.
3. Run all cells from top to bottom.
4. If needed, install dependencies: pip install pandas numpy matplotlib scikit-learn scipy

MINIMAL CHANGES MADE
KNN notebook:
- Replaced DecisionTreeClassifier with KNeighborsClassifier.
- Updated GridSearchCV parameter names/grid to KNN's n_neighbors and weights.
- Added StandardScaler before KNN in both branches because distance-based KNN is sensitive to feature scale.
- Kept preprocessing, train/test split, PCA comparison, cross-validation, classification metrics, paired t-test, and chart structure.

Linear Regression notebook:
- Replaced DecisionTreeClassifier with LinearRegression.
- Adapted parameter grids to fit_intercept and PCA component count.
- Changed stratified split to ordinary train_test_split because regression targets are numeric.
- Changed StratifiedKFold to KFold and CV scoring to negative MSE.
- Replaced classification metrics/confusion matrices with MAE, MSE, RMSE, and R2.
- Changed the final comparison chart from accuracy to test MSE (lower is better).
- Kept preprocessing, train/test split proportions, PCA vs no-PCA comparison, GridSearchCV, cross-validation, paired t-test, and comparison-chart structure.

DATA
The CSVs are small synthetic sample datasets for checking that the notebooks run. They are not real-world datasets or evidence of model performance on a real task.
